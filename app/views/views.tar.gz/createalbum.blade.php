@extends('default')

@section('content')

<div class="span4" style="display: inline-block; margin-top:100px;">
	@if ($errors->has())
	<div class="alert alert-danger fade in" id="error-block">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<h4>Warning!</h4>
		<ul>
			@foreach($errors->all('<li>:message</li>') as $message)
			{{ $message }}
			@endforeach
		</ul>
	</div>
	@endif

	<form name="createnewalbum" method="POST" action="{{ URL::route('create_album') }}" enctype="multipart/form-data">
		<fieldset>
			<legend>Create an Album</legend>
			<div class="form-group">
				<label for="name">Album Name</label>
				<input name="name" type="text" class="form-control" placeholder="Album Name" value="{{ Input::old('name') }}">
			</div>
			<div class="form-group">
				<label for="description">Album Description</label>
				<textarea name="description" type="text"class="form-control" placeholder="Album description">{{ Input::old('descrption') }}
				</textarea>
			</div>
			<div class="form-group">
				<label for="cover_image">Select a Cover Image </label>
				{{ Form::file('cover_image', array('class' => 'form-control')) }}
			</div>
			<button type="submit" class="btn btn-default">Create!</button>
		</fieldset>
	</form>
</div>

@stop